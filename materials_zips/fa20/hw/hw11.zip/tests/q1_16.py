test = {
  'name': 'q1_16',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> type(greatest_career_length_residual) == str
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
