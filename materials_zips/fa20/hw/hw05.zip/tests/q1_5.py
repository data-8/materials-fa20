test = {
  'name': 'q1_5',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> is_multiple_6_or_8(24)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> type(some_string) == str
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
