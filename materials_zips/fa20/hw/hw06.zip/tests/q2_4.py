test = {
  'name': 'q2_4',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # Remember, there are 5000 simulations. We want to find all the times "Data 8" appears out of all the 6-letter strings that appear.;
          >>> # See chapter 9.3 for an example of this!;
          >>> data_proportion == 0
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
