test = {
  'name': 'q11',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> number_cheese == 3
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
